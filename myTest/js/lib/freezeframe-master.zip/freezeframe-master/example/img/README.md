Image Credit
------------

Copyright 2012 http://headlikeanorange.tumblr.com
- ants.gif
- felix_baumgartner.gif
- lightning.gif
- pugs.gif
- running.gif
- subway.gif

Copyright 2012 http://black-and-white-gifs.tumblr.com
- times_square.gif